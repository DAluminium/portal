// Load before the application's scripts. Version belongs to the returned data,
// never to a global 'last GET', so polling cannot bless an old payload.
(function(){
 const original=window.fetch.bind(window);
 const endpoint='https://daluminium-api.daluminium2.workers.dev';
 window.fetch=async function(input,options={}){
  const url=new URL(typeof input==='string'?input:input.url,location.href);
  if(url.origin!==endpoint)return original(input,options);
  const headers=new Headers(options.headers||(input instanceof Request?input.headers:undefined));
  headers.delete('Origin');headers.delete('X-User');headers.delete('X-Pass');
  const method=(options.method||(input instanceof Request?input.method:'GET')).toUpperCase();
  if(method==='PATCH'){
   let b;try{b=JSON.parse(options.body);}catch{return new Response(JSON.stringify({erro:'corpo_invalido'}),{status:400});}
   const version=b.expectedVersion||b.data?._securityVersion;
   if(!version)return new Response(JSON.stringify({erro:'recarregue_antes_de_salvar'}),{status:428});
   headers.set('If-Match','"'+version+'"');
   if(b.data)delete b.data._securityVersion;
   delete b.expectedVersion;
   options={...options,body:JSON.stringify(b)};
  }
  const response=await original(input,{...options,headers});
  const parse=response.json.bind(response);
  response.json=async function(){
   const data=await parse();
   const version=response.headers.get('ETag')?.replace(/^"|"$/g,'');
   if(response.ok&&data&&typeof data==='object'&&!Array.isArray(data)&&version)data._securityVersion=version;
   return data;
  };
  if(!response.ok&&method==='PATCH'){
   const text=response.status===409?'Outra pessoa alterou os dados. Recarregue e confira antes de salvar novamente.':response.status===403?'Seu acesso não permite esta alteração.':response.status===428?'Recarregue os dados antes de salvar.':'O servidor recusou a gravação. Nenhuma confirmação de salvamento deve ser considerada válida.';
   window.dispatchEvent(new CustomEvent('daluminium-save-error',{detail:{status:response.status,message:text}}));
  }
  return response;
 };
})();
