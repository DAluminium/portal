import {AccessError, resolveSystem, corsHeaders, dataUrl, authorizeUser, issueToken, verifyToken, assertModuleAccessChange, requireLoginLimits} from './security.mjs';
const BASE='https://jirtkaaflnkwasorbita.supabase.co';
const ROLES={admin:3,gerente:2,compras:1,financeiro:1,consulta:1,user:1};
const clean=u=>Object.fromEntries(Object.entries(u).filter(([k])=>!['password','authVersion'].includes(k)));
const same=(a,b)=>JSON.stringify(a)===JSON.stringify(b);
const name=u=>String(u.username||'').toLowerCase();
const safeObject=x=>x && typeof x==='object' && !Array.isArray(x);
const hex=b=>Array.from(new Uint8Array(b),v=>v.toString(16).padStart(2,'0')).join('');
async function sha(s){return hex(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(s)));}
export function createWorker(fetcher=fetch){
 return {async fetch(request,env){
  let headers={'Cache-Control':'no-store','Content-Type':'application/json','X-Content-Type-Options':'nosniff'};
  const reply=(body,status=200,extra={})=>new Response(JSON.stringify(body),{status,headers:{...headers,...extra}});
  try{
   headers={...headers,...corsHeaders(request.headers.get('Origin')||'')};
   if(request.method==='OPTIONS') return new Response(null,{status:204,headers});
   if(!env.SUPA_SECRET) throw new AccessError(503,'configuracao_banco');
   if((env.MANUTENCAO||'').trim()) return reply({erro:'manutencao',mensagem:env.MANUTENCAO},503);
   const dbHeaders={apikey:env.SUPA_SECRET,Authorization:'Bearer '+env.SUPA_SECRET};
   async function rpc(fn,args){
    const r=await fetcher(BASE+'/rest/v1/rpc/'+fn,{method:'POST',headers:{...dbHeaders,'Content-Type':'application/json'},body:JSON.stringify(args),signal:AbortSignal.timeout(10000)});
    if(!r.ok)throw new AccessError(503,'configuracao_senhas');
    return r.json();
   }
   async function storePassword(digest){
    if(typeof digest!=='string'||! /^[a-f0-9]{64}$/.test(digest))throw new AccessError(400,'senha_invalida');
    const hash=await rpc('security_hash_password',{password_digest:digest});
    if(typeof hash!=='string'||!hash.startsWith('$2'))throw new AccessError(503,'configuracao_senhas');
    return 'bcrypt-sha256$'+hash;
   }
   async function passwordMatches(password,stored){
    if(typeof stored!=='string'||!stored)return false;
    if(stored.startsWith('bcrypt-sha256$'))return await rpc('security_verify_password',{password_digest:await sha(password),stored_hash:stored.slice('bcrypt-sha256$'.length)})===true;
    return /^[a-f0-9]{64}$/.test(stored)?await sha(password)===stored:password===stored;
   }
   async function read(system){
    const r=await fetcher(dataUrl(BASE,system),{headers:dbHeaders,signal:AbortSignal.timeout(10000)});
    if(!r.ok) throw new AccessError(502,'falha_leitura_banco');
    const rows=await r.json();
    if(!Array.isArray(rows)||rows.length!==1||!safeObject(rows[0].data)||typeof rows[0].updated_at!=='string') throw new AccessError(404,'registro_indisponivel');
    return rows[0];
   }
   async function write(row,data,expected){
    if(!expected) throw new AccessError(428,'recarregue_antes_de_salvar');
    if(expected!==row.updated_at) throw new AccessError(409,'dados_alterados_recarregue');
    const url=dataUrl(BASE,row.id);url.searchParams.set('updated_at','eq.'+expected);
    const version=new Date(Math.max(Date.now(),Date.parse(row.updated_at)+1)).toISOString();
    const r=await fetcher(url,{method:'PATCH',headers:{...dbHeaders,'Content-Type':'application/json',Prefer:'return=representation'},body:JSON.stringify({data,updated_at:version}),signal:AbortSignal.timeout(10000)});
    if(!r.ok) throw new AccessError(502,'falha_gravacao_banco');
    const rows=await r.json();
    if(!Array.isArray(rows)||rows.length!==1) throw new AccessError(409,'dados_alterados_recarregue');
    return rows[0].updated_at;
   }
   async function body(){
    if(!request.headers.get('Content-Type')?.toLowerCase().startsWith('application/json')) throw new AccessError(415,'use_json');
    const reader=request.body?.getReader();if(!reader) throw new AccessError(400,'corpo_invalido');
    const chunks=[];let size=0;
    while(true){const x=await reader.read();if(x.done)break;size+=x.value.length;if(size>2000000){await reader.cancel();throw new AccessError(413,'dados_muito_grandes');}chunks.push(x.value);}
    const data=new Uint8Array(size);let offset=0;for(const chunk of chunks){data.set(chunk,offset);offset+=chunk.length;}
    try{const b=JSON.parse(new TextDecoder().decode(data));if(!safeObject(b))throw 0;return b;}catch{throw new AccessError(400,'corpo_invalido');}
   }
   const action=request.headers.get('X-Action')||'';
   let usersRow;
   async function users(){
    usersRow??=await read('compras');
    const list=usersRow.data.usuarios;
    if(!Array.isArray(list)||new Set(list.map(name)).size!==list.length) throw new AccessError(503,'cadastro_inconsistente');
    return list;
   }
   if(action==='login'){
    if(request.method!=='POST')throw new AccessError(405,'use_post');
    const b=await body();const username=String(b.usuario||'').trim().toLowerCase();
    if(!username||typeof b.senha!=='string'||!b.senha||username.length>100||b.senha.length>1024) throw new AccessError(400,'credenciais_invalidas');
    await requireLoginLimits(env,request.headers.get('CF-Connecting-IP'),username);
    const list=await users();let u=list.find(x=>name(x)===username);
    if(!u||u.active===false||!await passwordMatches(b.senha,u.password))throw new AccessError(401,'credenciais_invalidas');
    if(!ROLES[u.role])throw new AccessError(403,'papel_recusado');
    // Upgrade legacy password only after a successful login, using CAS.
    if(!u.password.startsWith('bcrypt-sha256$')){
     u={...u,password:await storePassword(await sha(b.senha))};
     await write(usersRow,{...usersRow.data,usuarios:list.map(x=>name(x)===username?u:x)},usersRow.updated_at);
    }
    return reply({ok:true,token:await issueToken(u,env.TOKEN_SECRET),nome:u.name,username:u.username,role:u.role,modulos:u.role==='admin'?['compras','financeiro','fabrica','obra']:(u.modulos||[]),tempPass:u.tempPass===true});
   }
   const actor=await verifyToken(request.headers.get('Authorization'),env.TOKEN_SECRET,async username=>(await users()).find(u=>u.username===username));
   const visible=list=>list.filter(u=>actor.role==='admin'||name(u)===name(actor)||(actor.role==='gerente'&&u.criadoPor===actor.username)).map(clean);
   if(action==='users-list'){
    if(request.method!=='GET')throw new AccessError(405,'use_get');
    return reply({usuarios:visible(await users())},200,{ETag:'"'+usersRow.updated_at+'"'});
   }
   if(action==='users-save'){
    if(request.method!=='PATCH')throw new AccessError(405,'use_patch');
    const b=await body();if(!Array.isArray(b.usuarios))throw new AccessError(400,'usuarios_invalidos');
    const old=await users();const permitted=visible(old);const proposed=b.usuarios;
    if(proposed.some(u=>!safeObject(u)||! /^[a-z0-9][a-z0-9 ._-]{0,99}$/.test(u.username||''))||new Set(proposed.map(name)).size!==proposed.length)throw new AccessError(400,'usuarios_invalidos');
    const keep=new Map(old.map(u=>[name(u),u]));
    const allowedKeys=new Set(['username','name','role','modulos','active','whatsapp','password','tempPass','criadoPor','criadoEm','_needsReset']);
    for(const incoming of proposed){
     const current=keep.get(name(incoming));
     if(Object.keys(incoming).some(k=>!allowedKeys.has(k)))throw new AccessError(400,'campo_usuario_invalido');
     const publicCurrent=current?clean(current):null;
     if(current && same(publicCurrent,incoming))continue;
     if(current && !permitted.some(u=>name(u)===name(current)))throw new AccessError(403,'usuario_recusado');
     const own=current&&name(current)===name(actor);
     if(own){
      const unchanged={...incoming};delete unchanged.password;unchanged.tempPass=publicCurrent.tempPass;
      if(!same(publicCurrent,unchanged)||!incoming.password)throw new AccessError(403,'alteracao_propria_recusada');
     }else{
      if(!['admin','gerente'].includes(actor.role))throw new AccessError(403,'cadastro_recusado');
      if(actor.role!=='admin' && ((current&&ROLES[current.role]>=ROLES[actor.role])||!ROLES[incoming.role]||ROLES[incoming.role]>=ROLES[actor.role]))throw new AccessError(403,'hierarquia_recusada');
     }
     if(!ROLES[incoming.role])throw new AccessError(400,'papel_invalido');
     assertModuleAccessChange(actor,current,incoming);
     if(!current && !incoming.password)throw new AccessError(400,'senha_necessaria');
     const next={...incoming,username:current?.username||incoming.username,password:current?.password,criadoPor:current?.criadoPor||actor.username,criadoEm:current?.criadoEm||Date.now(),authVersion:current?.authVersion||0};
     if(incoming.password){next.password=await storePassword(incoming.password);next.tempPass=!own;}
     keep.set(name(next),next);
    }
    for(const u of permitted)if(!proposed.some(p=>name(p)===name(u))){
     if(name(u)===name(actor)||!['admin','gerente'].includes(actor.role)||(actor.role!=='admin'&&ROLES[u.role]>=ROLES[actor.role]))throw new AccessError(403,'remocao_recusada');
     keep.delete(name(u));
    }
    const list=[...keep.values()];if(!list.some(u=>u.role==='admin'&&u.active!==false))throw new AccessError(409,'ultimo_admin');
    const expected=request.headers.get('If-Match')?.replace(/^"|"$/g,'');
    const version=await write(usersRow,{...usersRow.data,usuarios:list},expected);
    const updated=list.find(u=>name(u)===name(actor));
    return reply({ok:true,usuarios:visible(list),token:await issueToken(updated,env.TOKEN_SECRET)},200,{ETag:'"'+version+'"'});
   }
   if(action)throw new AccessError(400,'acao_invalida');
   const system=resolveSystem(request.headers.get('X-Sistema'));
   const personal=system==='sessions'||system.startsWith('lembretes');
   if(personal){
    if(!['GET','PATCH'].includes(request.method))throw new AccessError(405,'metodo_recusado');
    if(system.endsWith('_teste')&&!['admin','gerente'].includes(actor.role))throw new AccessError(403,'teste_recusado');
   }else authorizeUser(actor,system,request.method);
   const row=await read(system);
   function view(data){
    if(system.startsWith('lembretes')&&actor.role!=='admin')return {lembretes:(data.lembretes||[]).filter(l=>String(l.user||'').toLowerCase()===name(actor))};
    if(system==='sessions'&&actor.role!=='admin'){
     const mine=(data.ativas||[]).filter(s=>String(s.username||'').toLowerCase()===name(actor));
     return {ativas:mine,encerradas:(data.encerradas||[]).filter(s=>String(s.username||'').toLowerCase()===name(actor)),forceLogout:(data.forceLogout||[]).filter(id=>mine.some(s=>s.sessionId===id))};
    }
    return {...data,...(Array.isArray(data.usuarios)?{usuarios:visible(data.usuarios)}:{})};
   }
   if(request.method==='GET')return reply(view(row.data),200,{ETag:'"'+row.updated_at+'"'});
   const b=await body();const incoming=b.data??b;if(!safeObject(incoming))throw new AccessError(400,'dados_invalidos');
   let next;
   if(personal && actor.role!=='admin'){
    next={...row.data};
    const fields=system==='sessions'?['ativas','encerradas','forceLogout']:['lembretes'];
    if(Object.keys(incoming).some(k=>!fields.includes(k)))throw new AccessError(400,'campo_invalido');
    for(const field of fields){
     const items=incoming[field]||[];if(!Array.isArray(items))throw new AccessError(400,'dados_invalidos');
     if(field==='forceLogout'){
      const mine=view(row.data).forceLogout;
      if(items.some(id=>!mine.includes(id)))throw new AccessError(403,'sessao_recusada');
      next[field]=(row.data[field]||[]).filter(id=>!mine.includes(id)).concat(items);
     }else{
      const owner=system==='sessions'?'username':'user';
      if(items.some(x=>!safeObject(x)||String(x[owner]||'').toLowerCase()!==name(actor)))throw new AccessError(403,'proprietario_recusado');
      if(system==='sessions'&&field==='ativas'&&items.some(x=>(row.data.ativas||[]).some(s=>s.sessionId===x.sessionId&&String(s.username||'').toLowerCase()!==name(actor))))throw new AccessError(403,'sessao_recusada');
      next[field]=(row.data[field]||[]).filter(x=>String(x[owner]||'').toLowerCase()!==name(actor)).concat(items);
     }
    }
   }else{
    if(!same(view(row.data).usuarios,incoming.usuarios))throw new AccessError(403,'use_cadastro_usuarios');
    next={...incoming,...(row.data.usuarios?{usuarios:row.data.usuarios}:{})};
   }
   const version=await write(row,next,request.headers.get('If-Match')?.replace(/^"|"$/g,''));
   return reply({ok:true},200,{ETag:'"'+version+'"'});
  }catch(e){
   if(e instanceof AccessError)return reply({ok:false,erro:e.code},e.status);
   console.error('daluminium_worker_failed',e?.name||'Error');
   return reply({ok:false,erro:'erro_interno'},500);
  }
 }};
}
export default createWorker();
