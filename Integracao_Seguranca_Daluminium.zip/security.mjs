// Foundation for integration into daluminium-api. Not a deployable Worker.
const SYSTEMS = new Set(['compras','financeiro','fabrica','obra','compras_teste','financeiro_teste','fabrica_teste','obra_teste','sessions','lembretes','lembretes_teste']);
const ORIGINS = new Set(['https://daluminium.github.io']);
export class AccessError extends Error {
  constructor(status, code) { super(code); this.status=status; this.code=code; }
}
export function resolveSystem(raw) {
  if (!SYSTEMS.has(raw)) throw new AccessError(400,'sistema_invalido');
  return raw;
}
export function corsHeaders(origin) {
  if (origin && !ORIGINS.has(origin)) throw new AccessError(403,'origem_recusada');
  return {
    ...(origin ? {'Access-Control-Allow-Origin':origin} : {}),
    'Vary':'Origin', 'Cache-Control':'no-store',
    'X-Content-Type-Options':'nosniff',
    'Access-Control-Allow-Methods':'GET, POST, PATCH, OPTIONS',
    'Access-Control-Allow-Headers':'Content-Type, X-Sistema, X-Action, Authorization, If-Match',
    'Access-Control-Expose-Headers':'ETag',
  };
}
export function dataUrl(base,system) {
  resolveSystem(system);
  const url=new URL('/rest/v1/app_data',base);
  url.searchParams.set('id','eq.'+system);
  url.searchParams.set('select','id,data,updated_at');
  return url;
}
// Must receive a fresh database record, never browser claims or cached roles.
export function authorizeUser(user,system,method) {
  resolveSystem(system);
  if (!user || user.active === false) throw new AccessError(401,'usuario_inativo');
  if (!['GET','PATCH'].includes(method)) throw new AccessError(405,'metodo_recusado');
  const role=String(user.role || '').toLowerCase();
  if (!['admin','gerente','compras','financeiro','consulta','user'].includes(role)) throw new AccessError(403,'papel_recusado');
  const test=system.endsWith('_teste');
  if (test && !['admin','gerente'].includes(role)) throw new AccessError(403,'teste_recusado');
  // Shared records need dedicated per-user endpoints; deny generic writes.
  if (system==='sessions' || system.startsWith('lembretes')) {
    if (role!=='admin') throw new AccessError(403,'endpoint_pessoal_necessario');
    return;
  }
  const module=test ? system.slice(0,-6) : system;
  if (role==='admin') return;
  if (!Array.isArray(user.modulos) || !user.modulos.includes(module)) throw new AccessError(403,'modulo_recusado');
  if (method==='PATCH' && module==='obra' && role!=='gerente') throw new AccessError(403,'obra_somente_admin_gerente');
  if (method==='PATCH' && role==='consulta') throw new AccessError(403,'somente_leitura');
}
function decode(s) {
  if (!/^[A-Za-z0-9_-]+$/.test(s)) throw new Error('encoding');
  return Uint8Array.from(atob(s.replace(/-/g,'+').replace(/_/g,'/')+'='.repeat((4-s.length%4)%4)),c=>c.charCodeAt(0));
}
function encode(bytes) {
  return btoa(String.fromCharCode(...bytes)).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
}
async function key(secret,usage) {
  if (typeof secret!=='string' || new TextEncoder().encode(secret).length<32) throw new AccessError(503,'configuracao_token');
  return crypto.subtle.importKey('raw',new TextEncoder().encode(secret),{name:'HMAC',hash:'SHA-256'},false,[usage]);
}
async function fingerprint(user,secret) {
  const bytes=new TextEncoder().encode(JSON.stringify([user.username,user.password,user.active!==false,user.role,user.modulos,user.authVersion||0]));
  return encode(new Uint8Array(await crypto.subtle.sign('HMAC',await key(secret,'sign'),bytes)));
}
export async function issueToken(user,secret,now=Date.now()) {
  const claims={u:user.username,n:user.name||user.username,r:user.role,m:user.role==='admin'?['compras','financeiro','fabrica','obra']:(user.modulos||[]),iat:now,exp:now+60*60*1000,v:await fingerprint(user,secret)};
  const payload=encode(new TextEncoder().encode(JSON.stringify(claims)));
  const signature=encode(new Uint8Array(await crypto.subtle.sign('HMAC',await key(secret,'sign'),new TextEncoder().encode(payload))));
  return payload+'.'+signature;
}
export async function verifyToken(auth,secret,loadUser,now=Date.now()) {
  const verifyKey=await key(secret,'verify');
  let claims;
  try {
    if (typeof auth!=='string' || !auth.startsWith('Bearer ') || auth.length>4096) throw new Error('token');
    const parts=auth.slice(7).split('.');
    if(parts.length!==2 || !(await crypto.subtle.verify('HMAC',verifyKey,decode(parts[1]),new TextEncoder().encode(parts[0])))) throw new Error('signature');
    claims=JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(decode(parts[0])));
    if (!claims || typeof claims.u!=='string' || !claims.u || !Number.isSafeInteger(claims.iat) || !Number.isSafeInteger(claims.exp) || claims.iat>now || claims.exp<=now || claims.exp<=claims.iat || claims.exp-claims.iat>3600000 || typeof claims.v!=='string') throw new Error('claims');
  } catch { throw new AccessError(401,'token_invalido'); }
  const user=await loadUser(claims.u);
  if(!user || user.username!==claims.u || user.active===false || await fingerprint(user,secret)!==claims.v) throw new AccessError(401,'sessao_revogada');
  return user;
}
export function assertOperationalWrite(current,incoming) {
  if (!incoming || typeof incoming!=='object' || Array.isArray(incoming)) throw new AccessError(400,'dados_invalidos');
  // User administration and password changes must use a separate endpoint.
  if(JSON.stringify(current?.usuarios)!==JSON.stringify(incoming.usuarios)) throw new AccessError(403,'cadastro_endpoint_separado');
}
// Dedicated user endpoints must call this with actor and target loaded from DB.
export function assertModuleAccessChange(actor,currentUser,incomingUser) {
  if (!actor || actor.active===false) throw new AccessError(401,'usuario_inativo');
  const before=currentUser?.modulos ?? [];
  const after=incomingUser?.modulos ?? [];
  if (!Array.isArray(before) || !Array.isArray(after) || after.some(m=>!['compras','financeiro','fabrica','obra'].includes(m)) || new Set(after).size!==after.length) throw new AccessError(400,'modulos_invalidos');
  const changed=JSON.stringify([...before].sort())!==JSON.stringify([...after].sort());
  if (changed && actor.role!=='admin') throw new AccessError(403,'acesso_modulos_somente_admin');
}
export async function requireLoginLimits(env,ip,username) {
  if(!ip || !env.LOGIN_IP_LIMIT?.limit || !env.LOGIN_USER_LIMIT?.limit) throw new AccessError(503,'configuracao_limite_login');
  const hash=encode(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(username.toLowerCase()))));
  const [a,b]=await Promise.all([env.LOGIN_IP_LIMIT.limit({key:ip}),env.LOGIN_USER_LIMIT.limit({key:hash})]);
  if(!a.success || !b.success) throw new AccessError(429,'limite_login');
}
