# Primeira etapa da reestruturação de segurança

**Atualização:** a integração local foi ampliada. Consulte [INTEGRACAO.md](INTEGRACAO.md) para os arquivos atuais, resultados dos testes e pendências. O restante deste documento descreve a fundação inicial.

Este pacote contém um módulo de segurança e testes locais. **Não é um Worker completo e não deve substituir o index.js em produção.** As proteções só passam a existir após integração e publicação validada.

## Implementado e testado localmente

- Lista fechada de sistemas e construção de consulta com URLSearchParams.
- Comparação exata de origem de produção.
- Permissões baseadas em cadastro atualizado no banco, não em papel informado pelo navegador.
- Impedimento de modificar usuários por gravação operacional genérica.
- Tokens assinados com uma hora de validade e revogação quando senha, papel, módulos, estado ativo ou authVersion mudam.
- Exigência de bindings de limite de tentativas por IP e usuário; falta de configuração recusa login.

## Integração necessária antes de publicar

1. Preservar cópia do Worker e backup restaurável dos dados. Identificar os repositórios e commits efetivamente publicados.
2. Conferir matriz real de permissões. Obra hoje grava também em Compras e Fábrica; autorizar essas integrações por operações específicas, sem liberar o JSON completo.
3. Separar cadastro e troca de senha em endpoints próprios; retirar hashes de senha das respostas de dados. Criar regras de hierarquia e propriedade no servidor.
4. Separar sessões e lembretes por usuário. A fundação recusa acesso genérico de não administradores a esses registros e, portanto, não é compatível com o frontend atual sem adaptações.
5. Atualizar o login para emitir o novo token e todos os módulos para ler o novo formato. O frontend atual depende dos campos n, r e m; precisa ser adaptado. Usar sempre o cadastro atual como autoridade.
6. Remover fallback de senhas antigas de administradores. Definir recuperação administrativa independente e rastreável.
7. Migrar senhas para Supabase Auth ou algoritmo adequado com salt e custo. A fundação não implementa armazenamento nem verificação de senhas.
8. Conectar requireLoginLimits antes de consultar senhas; obter IP do cabeçalho CF-Connecting-IP no Worker. Bindings Cloudflare são aproximados e locais por localização; avaliar contador central para bloqueio rigoroso.
9. Conectar verificação de token e autorização a todas as leituras e gravações. loadUser deve buscar registro único e atual no banco, sem fallback em variáveis de admin.
10. Implementar atualização condicional atômica por versão no banco. Sem If-Match, recusar alterações; versões desatualizadas retornam 409. Validar esquema, tamanho e campos de cada operação.
11. Tratar falha do Supabase como erro, confirmar linha alterada e esconder detalhes internos. Adicionar auditoria sem senhas e tokens.
12. Corrigir inserção de campos em innerHTML e postMessage sem verificação de origem nos clientes.
13. Revisar funções SECURITY DEFINER, privilégios EXECUTE e search_path. Conferir agendamento, retenção e restauração dos backups próprios.
14. Validar em ambiente isolado com dados fictícios: login, quatro módulos, integração Obra, cadastro, troca de senha, sessões e lembretes. Depois aprovar publicação e procedimento de rollback.

## Pendências

Somente admin pode conceder, retirar ou alterar acesso a módulos, inclusive durante o cadastro. Gerente pode criar usuário sem módulos liberados; não pode atribuir admin nem alterar permissões por outro campo. O endpoint específico deverá chamar assertModuleAccessChange com cadastros atuais buscados no banco. Não aplicar módulos padrão quando a lista estiver vazia: os frontends atuais ainda precisam dessa adaptação. Cadastro com role admin fica reservado a admin, pois esse papel implica acesso total.

Regra confirmada: admin tem acesso total a todos os módulos, em produção e teste. Em Obra, admin e gerente podem alterar; gerente precisa ter o módulo autorizado. Outros cargos têm somente leitura em Obra quando autorizados. Cadastro de usuários será permitido apenas a admin e gerente, com hierarquia aplicada no endpoint específico a implementar. Acesso total de admin não dispensa assinatura de token, usuário ativo, validação de dados ou endpoints próprios para operações sensíveis.

Nenhuma alteração aplicada ao Cloudflare, Supabase ou GitHub. Não há garantia de segurança máxima; a reestruturação precisa de validação contínua. Testes usam usuários fictícios e não fazem chamadas externas.

Referências: https://developers.cloudflare.com/workers/runtime-apis/bindings/rate-limit/ e https://supabase.com/docs/guides/auth/password-security
