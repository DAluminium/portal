import test from 'node:test';
import assert from 'node:assert/strict';
import {createWorker} from './worker.mjs';
import {issueToken} from './security.mjs';
const secret='test-only-secret-at-least-32-bytes-long';
const admin={username:'admin',name:'Admin',role:'admin',modulos:[],password:'secret-test',active:true};
const manager={username:'gerente',name:'Gerente',role:'gerente',modulos:['obra','compras'],password:'secret-test',active:true};
const reader={username:'consulta',name:'Consulta',role:'consulta',modulos:['obra','compras'],password:'secret-test',active:true,criadoPor:'gerente'};
function fixture(){
 const rows=new Map(['compras','financeiro','obra','fabrica','sessions','lembretes'].map(id=>[id,{id,updated_at:'2026-09-14T01:00:00.000Z',data:id==='sessions'?{ativas:[{username:'admin',sessionId:'a'},{username:'consulta',sessionId:'c'}],encerradas:[],forceLogout:[]}:id==='lembretes'?{lembretes:[{user:'admin',texto:'private'},{user:'consulta',texto:'own'}]}:{usuarios:[admin,manager,reader],obras:[]}}]));
 const calls=[];
 const fetcher=async(input,init={})=>{
  const u=new URL(input);calls.push({u,init});
  if(u.pathname.includes('/rpc/'))return Response.json(u.pathname.endsWith('security_hash_password')?'$2a$12$mock-for-tests':true);
  const id=u.searchParams.get('id')?.slice(3);const row=rows.get(id);
  if(init.method==='PATCH'){
   if(!row||u.searchParams.get('updated_at')?.slice(3)!==row.updated_at)return Response.json([]);
   const b=JSON.parse(init.body);const next={...row,...b};rows.set(id,next);return Response.json([next]);
  }
  return Response.json(row?[row]:[]);
 };
 const env={SUPA_SECRET:'test-secret',TOKEN_SECRET:secret,LOGIN_IP_LIMIT:{limit:async()=>({success:true})},LOGIN_USER_LIMIT:{limit:async()=>({success:true})}};
 const worker=createWorker(fetcher);
 async function request(actor,system,method='GET',body,action='',version){
  const token=await issueToken(actor,secret);
  return worker.fetch(new Request('https://worker.test/',{method,headers:{Origin:'https://daluminium.github.io',Authorization:'Bearer '+token,'X-Sistema':system,'X-Action':action,'Content-Type':'application/json',...(version?{'If-Match':'"'+version+'"'}:{})},...(body?{body:JSON.stringify(body)}:{})}),env);
 }
 return {rows,calls,env,worker,request};
}
test('unauthenticated and manipulated systems never reach data queries',async()=>{
 const f=fixture();assert.equal((await f.worker.fetch(new Request('https://worker.test/',{headers:{'X-Sistema':'compras'}}),f.env)).status,401);
 const r=await f.request(admin,'compras&or=(id.eq.financeiro)');assert.equal(r.status,400);
 assert.equal(f.calls.filter(c=>c.u.searchParams.get('id')?.includes('&')).length,0);
});
test('admin can read every module; consulta cannot write Obra',async()=>{
 const f=fixture();assert.equal((await f.request(admin,'financeiro')).status,200);
 assert.equal((await f.request(reader,'obra','PATCH',{data:{obras:[]}})).status,403);
 const r=await f.request(manager,'obra');assert.equal(r.status,200);
 const data=await r.json();assert(!data.usuarios.some(u=>'password'in u));
});
test('atomic version check prevents stale writes and missing rows are failures',async()=>{
 const f=fixture(),row=f.rows.get('obra');
 const data=await(await f.request(admin,'obra')).json();data.obras=[{id:1}];
 assert.equal((await f.request(admin,'obra','PATCH',{data})).status,428);
 assert.equal((await f.request(admin,'obra','PATCH',{data},'',row.updated_at)).status,200);
 assert.equal((await f.request(admin,'obra','PATCH',{data},'',row.updated_at)).status,409);
 f.rows.delete('obra');assert.equal((await f.request(admin,'obra')).status,404);
});
test('generic JSON write cannot change roles or passwords',async()=>{
 const f=fixture(),data=await(await f.request(admin,'compras')).json();
 data.usuarios[1].role='admin';
 assert.equal((await f.request(admin,'compras','PATCH',{data},'',f.rows.get('compras').updated_at)).status,403);
});
test('gerente cannot grant modules or create admin; admin can grant modules',async()=>{
 const f=fixture(),row=f.rows.get('compras');
 const list=(await(await f.request(manager,'compras','GET',null,'users-list')).json()).usuarios;
 const own=list.find(u=>u.username==='consulta');own.modulos=['financeiro'];
 assert.equal((await f.request(manager,'compras','PATCH',{usuarios:list},'users-save',row.updated_at)).status,403);
 own.modulos=['obra','compras'];own.role='admin';
 assert.equal((await f.request(manager,'compras','PATCH',{usuarios:list},'users-save',row.updated_at)).status,403);
 const all=(await(await f.request(admin,'compras','GET',null,'users-list')).json()).usuarios;
 all.find(u=>u.username==='consulta').modulos=['financeiro'];
 assert.equal((await f.request(admin,'compras','PATCH',{usuarios:all},'users-save',row.updated_at)).status,200);
 assert.equal(f.rows.get('compras').data.usuarios.find(u=>u.username==='consulta').password,reader.password);
});
test('gerente creates lower-ranked account with no module grant',async()=>{
 const f=fixture(),row=f.rows.get('compras');
 const list=(await(await f.request(manager,'compras','GET',null,'users-list')).json()).usuarios;
 list.push({username:'novo',name:'Novo',role:'consulta',modulos:[],active:true,password:'a'.repeat(64)});
 const r=await f.request(manager,'compras','PATCH',{usuarios:list},'users-save',row.updated_at);
 assert.equal(r.status,200);const stored=f.rows.get('compras').data.usuarios.find(u=>u.username==='novo');
 assert.deepEqual(stored.modulos,[]);assert(stored.password.startsWith('bcrypt-sha256$'));
 assert.equal(stored.criadoPor,'gerente');assert(!((await r.json()).usuarios.find(u=>u.username==='novo').password));
});
test('inactive user does not regain access through Cloudflare fallback',async()=>{
 const f=fixture();f.env.ADMIN_ANDER='secret-test';f.rows.get('compras').data.usuarios[0]={...admin,active:false};
 const r=await f.worker.fetch(new Request('https://worker.test/',{method:'POST',headers:{'Content-Type':'application/json','X-Action':'login','CF-Connecting-IP':'127.0.0.1'},body:JSON.stringify({usuario:'admin',senha:'secret-test'})}),f.env);
 assert.equal(r.status,401);
});
test('login upgrades legacy hash and returns compatible claims without passwords',async()=>{
 const f=fixture();
 const r=await f.worker.fetch(new Request('https://worker.test/',{method:'POST',headers:{'Content-Type':'application/json','X-Action':'login','CF-Connecting-IP':'127.0.0.1'},body:JSON.stringify({usuario:'admin',senha:'secret-test'})}),f.env);
 assert.equal(r.status,200);const data=await r.json();assert(!('password'in data));assert(data.modulos.includes('obra'));
 const claims=JSON.parse(Buffer.from(data.token.split('.')[0],'base64url').toString());assert.equal(claims.r,'admin');assert.equal(claims.n,'Admin');
 assert(f.rows.get('compras').data.usuarios[0].password.startsWith('bcrypt-sha256$'));
});
test('personal reads exclude other users and writes reject owner impersonation',async()=>{
 const f=fixture();const d=await(await f.request(reader,'lembretes')).json();assert.equal(d.lembretes.length,1);
 assert.equal((await f.request(reader,'lembretes','PATCH',{data:{lembretes:[{user:'admin',texto:'fake'}]}},'',f.rows.get('lembretes').updated_at)).status,403);
 const s=await(await f.request(reader,'sessions')).json();assert.deepEqual(s.ativas.map(x=>x.username),['consulta']);
});
