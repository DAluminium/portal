-- Review and apply in an isolated Supabase project first. No user data changes.
-- Requires pgcrypto installed in extensions (verify before running).
begin;
create or replace function public.security_hash_password(password_digest text)
returns text language plpgsql security invoker
set search_path = ''
as $$
begin
 if password_digest !~ '^[a-f0-9]{64}$' or password_digest is null then
  raise exception 'Invalid digest';
 end if;
 return extensions.crypt(password_digest, extensions.gen_salt('bf',12));
end;
$$;
create or replace function public.security_verify_password(password_digest text,stored_hash text)
returns boolean language plpgsql security invoker
set search_path = ''
as $$
begin
 if password_digest !~ '^[a-f0-9]{64}$' or password_digest is null
  or stored_hash !~ '^\$2[aby]\$12\$' or stored_hash is null then
  return false;
 end if;
 return extensions.crypt(password_digest,stored_hash)=stored_hash;
end;
$$;
revoke all on function public.security_hash_password(text) from public, anon, authenticated;
revoke all on function public.security_verify_password(text,text) from public, anon, authenticated;
grant execute on function public.security_hash_password(text) to service_role;
grant execute on function public.security_verify_password(text,text) to service_role;
commit;
