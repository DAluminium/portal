import test from 'node:test';
import assert from 'node:assert/strict';
import {resolveSystem,corsHeaders,dataUrl,authorizeUser,issueToken,verifyToken,assertOperationalWrite,requireLoginLimits,assertModuleAccessChange} from './security.mjs';
const secret='test-only-32-byte-secret-do-not-deploy';
const now=10000000;
const user={username:'test',password:'test-hash',active:true,role:'compras',modulos:['compras']};
test('only admin grants or revokes module access including on new accounts',()=>{
 const admin={...user,role:'admin'},gerente={...user,role:'gerente'};
 assertModuleAccessChange(admin,user,{...user,modulos:['obra']});
 assertModuleAccessChange(admin,user,{...user,modulos:[]});
 assert.throws(()=>assertModuleAccessChange(gerente,user,{...user,modulos:[]}));
 assert.throws(()=>assertModuleAccessChange(gerente,null,{modulos:['compras']}));
 assertModuleAccessChange(gerente,null,{modulos:[]});
 assertModuleAccessChange(gerente,user,{...user});
 assert.throws(()=>assertModuleAccessChange({...admin,active:false},user,{modulos:[]}));
 assert.throws(()=>assertModuleAccessChange(admin,user,{modulos:['desconhecido']}));
});
test('reject unknown systems and query injection',()=>{
 for(const s of [null,'','other','compras&or=(id.eq.financeiro)','compras_teste&select=*']) assert.throws(()=>resolveSystem(s));
 assert.equal(dataUrl('https://example.supabase.co','compras').searchParams.get('id'),'eq.compras');
});
test('CORS exact match rejects prefix lookalikes and localhost',()=>{
 assert.equal(corsHeaders('https://daluminium.github.io')['Access-Control-Allow-Origin'],'https://daluminium.github.io');
 for(const s of ['https://daluminium.github.io.evil.example','http://localhost']) assert.throws(()=>corsHeaders(s));
 assert.equal(corsHeaders('')['Access-Control-Allow-Origin'],undefined);
});
test('only permitted modules are readable and writable',()=>{
 authorizeUser(user,'compras','GET'); authorizeUser(user,'compras','PATCH');
 assert.throws(()=>authorizeUser(user,'financeiro','GET'));
 assert.throws(()=>authorizeUser(user,'compras_teste','GET'));
 assert.throws(()=>authorizeUser({...user,role:'consulta'},'compras','PATCH'));
 assert.throws(()=>authorizeUser({...user,active:false},'compras','GET'));
});
test('generic writes cannot modify users or passwords',()=>{
 const d={usuarios:[user],obras:[]};
 assertOperationalWrite(d,{...d,obras:[{id:1}]});
 assert.throws(()=>assertOperationalWrite(d,{...d,usuarios:[{...user,role:'admin'}]}));
 assert.throws(()=>assertOperationalWrite(d,{obras:[]}));
});
test('admin has full module access and gerente can change authorized Obra',()=>{
 for(const system of ['obra','obra_teste']) {
   authorizeUser({...user,role:'gerente',modulos:['obra']},system,'PATCH');
   authorizeUser({...user,role:'admin',modulos:[]},system,'PATCH');
   for(const role of ['compras','financeiro','consulta','user']) assert.throws(()=>authorizeUser({...user,role,modulos:['obra']},system,'PATCH'));
 }
 authorizeUser({...user,role:'admin',modulos:['obra']},'obra','GET');
 assert.throws(()=>authorizeUser({...user,role:'gerente',modulos:[]},'obra','PATCH'));
 for(const system of ['compras','financeiro','fabrica','obra','compras_teste','financeiro_teste','fabrica_teste','obra_teste','sessions','lembretes','lembretes_teste']) for(const method of ['GET','PATCH']) authorizeUser({...user,role:'admin',modulos:[]},system,method);
});
test('shared records require dedicated endpoints for nonadmin',()=>{
 for(const s of ['sessions','lembretes']) for(const m of ['GET','PATCH']) assert.throws(()=>authorizeUser(user,s,m));
});
test('tokens are signed and expired or tampered tokens rejected',async()=>{
 const token=await issueToken(user,secret,now);
 assert.equal((await verifyToken('Bearer '+token,secret,async()=>user,now)).username,user.username);
 await assert.rejects(()=>verifyToken('Bearer '+token,secret,async()=>user,now+3600000));
 await assert.rejects(()=>verifyToken('Bearer x'+token,secret,async()=>user,now));
 await assert.rejects(()=>verifyToken('Bearer '+token,secret,async()=>user,now-1));
});
test('password change, disabled account and role change revoke token',async()=>{
 const token=await issueToken(user,secret,now);
 for(const changed of [{...user,password:'changed'},{...user,active:false},{...user,role:'admin'},{...user,modulos:['financeiro']},{...user,authVersion:1}]) await assert.rejects(()=>verifyToken('Bearer '+token,secret,async()=>changed,now));
});
test('login limits fail closed when missing and return denial on exhaustion',async()=>{
 await assert.rejects(()=>requireLoginLimits({},'127.0.0.1','test'));
 const allow={limit:async()=>({success:true})},deny={limit:async()=>({success:false})};
 await requireLoginLimits({LOGIN_IP_LIMIT:allow,LOGIN_USER_LIMIT:allow},'127.0.0.1','test');
 await assert.rejects(()=>requireLoginLimits({LOGIN_IP_LIMIT:deny,LOGIN_USER_LIMIT:allow},'127.0.0.1','test'),e=>e.status===429);
});
