import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import fs from 'node:fs';
const source=fs.readFileSync(new URL('./client-security.js',import.meta.url),'utf8');
function fixture(){
 const calls=[];let version='v1';
 const window={dispatchEvent(){},fetch:async(input,options)=>{calls.push({input,options});return Response.json({obras:[]},{headers:{ETag:'"'+version+'"'}});}};
 vm.runInNewContext(source,{window,URL,Headers,Request,Response,JSON,location:{href:'https://daluminium.github.io/portal/'},CustomEvent:class {constructor(type,init){this.type=type;this.detail=init.detail;}}});
 return {window,calls,setVersion(v){version=v;}};
}
test('adapter carries actual record version in write and never stores metadata',async()=>{
 const f=fixture();const data=await(await f.window.fetch('https://daluminium-api.daluminium2.workers.dev',{headers:{'X-Sistema':'obra'}})).json();
 assert.equal(data._securityVersion,'v1');
 await f.window.fetch('https://daluminium-api.daluminium2.workers.dev',{method:'PATCH',headers:{Origin:'https://daluminium.github.io','X-Sistema':'obra'},body:JSON.stringify({data})});
 assert.equal(f.calls[1].options.headers.get('If-Match'),'"v1"');
 assert.equal(f.calls[1].options.headers.get('Origin'),null);
 assert(!('_securityVersion' in JSON.parse(f.calls[1].options.body).data));
});
test('a later polling GET does not replace the version of an older payload',async()=>{
 const f=fixture();const old=await(await f.window.fetch('https://daluminium-api.daluminium2.workers.dev')).json();
 f.setVersion('v2');await(await f.window.fetch('https://daluminium-api.daluminium2.workers.dev')).json();
 await f.window.fetch('https://daluminium-api.daluminium2.workers.dev',{method:'PATCH',body:JSON.stringify({data:old})});
 assert.equal(f.calls[2].options.headers.get('If-Match'),'"v1"');
});
test('unversioned write is blocked without calling production',async()=>{
 const f=fixture();const r=await f.window.fetch('https://daluminium-api.daluminium2.workers.dev',{method:'PATCH',body:JSON.stringify({data:{obras:[]}})});
 assert.equal(r.status,428);assert.equal(f.calls.length,0);
});
test('adapter does not intercept other services',async()=>{
 const f=fixture();await f.window.fetch('https://example.com/file',{headers:{test:'value'}});
 assert.deepEqual(f.calls[0].options.headers,{test:'value'});
});
